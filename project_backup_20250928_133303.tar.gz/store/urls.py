from django.contrib import admin
from django.urls import path
from apps.catalog.views import product_list
from apps.orders.views import quick_buy

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', product_list, name='home'),
    path('orders/quick-buy/<int:product_id>/', quick_buy, name='quick_buy'),
]
