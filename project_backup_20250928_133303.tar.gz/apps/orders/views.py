from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from apps.catalog.models import Product, DigitalKey
from apps.orders.models import Order, OrderItem
from django.utils import timezone

@csrf_exempt
def quick_buy(request, product_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
    email = request.POST.get('email')
    if not email:
        return JsonResponse({'error': 'email required'}, status=400)
    product = get_object_or_404(Product, id=product_id)
    key = DigitalKey.objects.filter(product=product, assigned=False).first()
    if not key:
        return JsonResponse({'error': 'No keys available'}, status=409)
    order = Order.objects.create(email=email, paid=True)
    OrderItem.objects.create(order=order, product=product, quantity=1, allocated_key=key)
    key.assigned = True
    key.assigned_at = timezone.now()
    key.save()
    return JsonResponse({'order_id': order.id, 'key': key.key})
