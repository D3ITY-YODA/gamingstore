from django.db import models
from django.contrib.auth import get_user_model
from apps.catalog.models import Product, DigitalKey

User = get_user_model()

class Order(models.Model):
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    email = models.EmailField()
    created_at = models.DateTimeField(auto_now_add=True)
    paid = models.BooleanField(default=False)

    def __str__(self):
        return f"Order {self.id} - {self.email} - {'paid' if self.paid else 'pending'}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    allocated_key = models.ForeignKey(DigitalKey, null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return f"{self.product.title} x{self.quantity} (Order {self.order.id})"
