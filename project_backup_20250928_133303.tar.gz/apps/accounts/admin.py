from django.contrib import admin
from django.contrib.auth import get_user_model

# Avoid re-registering the built-in User model (prevents AlreadyRegistered)
# If you want to customize User admin later, unregister() first then register your custom admin.
User = get_user_model()

# No admin.site.register(User) here.
