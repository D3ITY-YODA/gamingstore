from django.db import models

class Platform(models.TextChoices):
    PC = 'PC', 'PC'
    PS5 = 'PS5', 'PlayStation 5'
    XBOX = 'XBOX', 'Xbox Series'

class Product(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    platform = models.CharField(max_length=10, choices=Platform.choices, default=Platform.PC)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.platform})"

class DigitalKey(models.Model):
    product = models.ForeignKey(Product, related_name='keys', on_delete=models.CASCADE)
    key = models.CharField(max_length=255)
    assigned = models.BooleanField(default=False)
    assigned_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Key for {self.product.title} - {'assigned' if self.assigned else 'available'}"
