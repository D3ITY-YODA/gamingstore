from django.contrib import admin
from .models import Product, DigitalKey

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'platform', 'price', 'created_at')

@admin.register(DigitalKey)
class DigitalKeyAdmin(admin.ModelAdmin):
    list_display = ('product', 'key', 'assigned', 'assigned_at')
    list_filter = ('assigned', 'product')
